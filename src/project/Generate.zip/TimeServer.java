package project;

public class TimeServer {
	private static int timeStamp, timeStamp1, timeStamp2;

	public TimeServer() {
		// TODO Auto-generated constructor stub
		timeStamp = 0;
	}
	private static void updateTime(int timeStamp, int client) {
		if (client == 0) {
			timeStamp1 = timeStamp;
		} else if (client == 1) {
			timeStamp2 = timeStamp;
		}
		timeStamp = Math.min(timeStamp1, timeStamp2);
	}
	public static int getTime(int time, int client) {
		updateTime(timeStamp, client);
		return timeStamp;
	}
	public void connect() {
		
	}
}
