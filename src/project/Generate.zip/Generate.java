package project;

import java.io.IOException;
import java.io.ObjectOutputStream;
import java.io.OutputStream;
import java.net.Socket;
import java.net.UnknownHostException;
import java.util.ArrayList;
import java.util.Random;

public class Generate {
	public Socket socket;
	static int PORT1 = 8080;
	static int PORT2 = 8081;
	static Integer id = 0;

	public Generate() {
		// �ֲ�
	}

	public void connect(int port) throws UnknownHostException, IOException {
		socket = new Socket("127.0.0.1", port);
	}
	public void closeConnect() throws IOException {
		socket.close();
	}
	public ArrayList<String> singleData() {
		ArrayList<String> data = new ArrayList<>();
		data.add(id.toString());
		id++;
		data.add(GeneratePriority().toString());
		data.add(GenerateTolerance().toString());
		return data;
	}

	public Integer GeneratePriority() {
		Random randomno = new Random();
		int a = (int) (1/(Math.exp(-randomno.nextGaussian()))) * 4 + 1;
		return a;
	}

	private Integer GenerateTolerance() {
		
		return 0;
	}

	public void sendData(ArrayList<String> data) throws IOException {
		OutputStream os = socket.getOutputStream();
		ObjectOutputStream oos = new ObjectOutputStream(os);
		oos.writeObject(data);
		oos.close();
	}

	
	public static void main(String[] args) throws UnknownHostException, IOException {
		Generate client = new Generate();
		client.connect(PORT1);
		while (true) {
			ArrayList<String> data = client.singleData();
			client.sendData(data);
		}
	}
}
